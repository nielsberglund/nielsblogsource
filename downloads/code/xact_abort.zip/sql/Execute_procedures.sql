
-- code for cleanup
-- TRUNCATE TABLE dbo.tb_OrderDetail

EXEC dbo.pr_1;
GO

SELECT * FROM dbo.tb_OrderDetail
GO